/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package verificafarsane;
import java.io.Serializable;
/**
 *
 * @author abdollah.farsane
 */
public class StudentiPerStatoEAnno implements Serializable{
    private String anno;
    private String Continente;
    private String Stato;
    private String TotaleFemmine;
    private String TotaleMaschi;
    private String TotaleStudenti;
    /**
     * metodo costruttore della classe StudentiPerStatoEAnno che definisce le caratteristiche dell'oggetto
     * @param anno
     * @param continente
     * @param stato
     * @param totaleFemmine
     * @param totaleMaschi
     * @param totaleStudenti 
     */
    public StudentiPerStatoEAnno(String anno, String continente,String stato,String totaleFemmine,String totaleMaschi,String totaleStudenti){
        this.anno = anno;
        this.Continente = continente;
        this.Stato = stato;
        this.TotaleFemmine = totaleFemmine;
        this.TotaleMaschi = totaleMaschi;
        this.TotaleStudenti = totaleStudenti;
    }
    /**
     * getter dell'anno
     * @return String
     */
    public String getAnno(){
        return anno;
    }
    /**
     * getter del continente
     * @return String
     */
    public String getContinente(){
        return Continente;
    }
    /**
     * getter dello stato
     * @return String
     */
    public String getStato(){
        return Stato;
    }
    /**
     * getter del totale femmine
     * @return String
     */
    public String getTotaleFemmine(){
        return TotaleFemmine;
    }
    /**
     * getter del totale maschi
     * @return String
     */
    public String getTotaleMaschi(){
        return TotaleMaschi;
    }
    /**
     * getter del totale studenti
     * @return String
     */
    public String getTotaleStudenti(){
        return TotaleMaschi;
    }
    
}

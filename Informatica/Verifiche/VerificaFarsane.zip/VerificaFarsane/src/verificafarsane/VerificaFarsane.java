/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package verificafarsane;

import java.io.IOException;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author abdollah.farsane
 */
public class VerificaFarsane {
    /**
     * Le seguenti variabili intere sono state impostate come globali per permettere ai metodi della classe VerificaFarsane di utlizzarle
     * Le variabili vengono utilizzate per il conteggio degli studenti americani nel 00/01 e 12/13
     * studentesseAmericane2000(Integer)
     * studentiAmericani2000(Integer)
     * totStudenti2000(Integer)
     * 
     * studentesseAmericane2012(Integer)
     * studentiAmericani2012 (Integer)
     * totStudenti2012(Integer)
     * 
     * continua (boolean)
     */
    static int studentesseAmericane2000 = 0;
    static int studentiAmericani2000 = 0;
    static int totStudenti2000 = 0;
    static int studentesseAmericane2012 = 0;
    static int studentiAmericani2012 = 0;
    static int totStudenti2012 = 0;
    static boolean continua = false;
    /**
     * 
     */
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        
        // TODO code application logic here
        /**
         * Oggetti di tipo StudentiPerContinenteEAnno istanziati passano loro i parametri relativi all'anno e al continente.
         * 
         */
        StudentiPerContinenteEAnno st_1 = new StudentiPerContinenteEAnno("2000-2001","AMERICA");
        StudentiPerContinenteEAnno st_2 = new StudentiPerContinenteEAnno("2012-2013","AMERICA");
        StudentiPerContinenteEAnno st_3 = new StudentiPerContinenteEAnno("2000-2001","AFRICA");
        StudentiPerContinenteEAnno st_4 = new StudentiPerContinenteEAnno("2012-2013","AFRICA");
        /**
         * Il seguente ciclo do/while utlizza la variabile continua (globale e booleana) che viene modificata nel metodo chiediSeRiavviare() che permette al
         * cliente di scegliere se terminare il programma o farlo riavviare normalmente
         * 
         */
        do{
        menu(st_1,st_2,st_3,st_4);
        }while(continua);
    }

    
    /**
     * Il metodo menu() riceve 4 parametri corrispondenti ai 4 oggetti istanziati precendentemente
     * Il metodo menu() è di tipo void perchè l'unico suo reale scopo è quello di visualizzare un semplice menu che permetta al cliente di orientarsi
     * @param st_1
     * @param st_2
     * @param st_3
     * @param st_4
     * @throws ClassNotFoundException 
     */
    public static void menu(StudentiPerContinenteEAnno st_1,StudentiPerContinenteEAnno st_2,StudentiPerContinenteEAnno st_3,StudentiPerContinenteEAnno st_4) throws ClassNotFoundException{
        System.out.println("Verifica di Informatica  -  JAVA");
        System.out.println("  1  -  Richiesta (4)");
        System.out.println("  2  -  Richiesta (5)");
        System.out.println("  3  -  Richiesta (6)");
        System.out.println("  4  -  Richiesta (7)");
        
        String scelta = input();
        
        switch(scelta){
            case "1":{
                richiesta4(st_1);
                chiediSeRiavviare();
                break;
            }
            case "2":{
                richiesta5(st_1,st_2);
                chiediSeRiavviare();
                break;
            }
            case "3":{
                richiesta6(st_3,st_4);
                chiediSeRiavviare();
                break;
            }
            case "4":{
                richiesta7(st_1);
                chiediSeRiavviare();
                break;
            }
        }
    }
    /**
     * metodo richiesta4() permette all'utente di visualizzare a monitor la lista degli stati del continente americano con il numero di studenti presenti in italia per l'anno 
     * scolastico 2000/2001
     * Viene utilizzato un System.out.format invece di un semplice .println per ordinare in una tabella i dati da visualizzare
     * @param st_1 
     */
    public static void richiesta4(StudentiPerContinenteEAnno st_1){
        System.out.format("|%1$-30s|%2$-12s|%3$-8s|\n","Stato","STUDENTESSE","STUDENTI");
        for(int i = 0; i<st_1.getSps().length;i++){
            if(st_1.getSps()[i] != null){
            System.out.format("|%1$-30s|%2$-12s|%3$-8s|\n", st_1.getSps()[i].getStato(),st_1.getSps()[i].getTotaleFemmine(),st_1.getSps()[i].getTotaleMaschi());
            }
        }
    }
    
    /**
     * metodo richiesta5() permette all'utente di visualizzare a monitor il calcolo della variazione degli studenti del continente americano presenti in italia dall'anno 2000/2001 al 2012/2013
     * @param st_1 oggetto (2000/2001,AMERICA)
     * @param st_2 oggetto (2012/2013,AMERICA)
     */
    public static void richiesta5(StudentiPerContinenteEAnno st_1,StudentiPerContinenteEAnno st_2){
        for(int i = 0; i<st_1.getSps().length;i++){
            if(st_1.getSps()[i] != null){
            studentesseAmericane2000 += Integer.parseInt(st_1.getSps()[i].getTotaleFemmine());
            studentiAmericani2000 += Integer.parseInt(st_1.getSps()[i].getTotaleMaschi());
            }
        }
        totStudenti2000 = studentesseAmericane2000 + studentiAmericani2000;
        for(int i = 0; i<st_2.getSps().length;i++){
            if(st_2.getSps()[i] != null){
            studentesseAmericane2012 += Integer.parseInt(st_2.getSps()[i].getTotaleFemmine());
            studentiAmericani2012 += Integer.parseInt(st_2.getSps()[i].getTotaleMaschi());
            }
        }
        totStudenti2012 = studentesseAmericane2012 + studentiAmericani2012;
        showRichiesta5(studentesseAmericane2012 - studentesseAmericane2000,studentiAmericani2012 - studentiAmericani2000,totStudenti2012 - totStudenti2000);
    }
    
    /**
     * metodo richiesta6() permette all'utente di visualizzare a monitor lo stato africano il maggior incremento di studenti in Italia nel periodo dall'anno 2000/2001 al 2012/2013
     * @param st_3 oggetto (2000/2001,AFRICA)
     * @param st_4 oggetto (2012/2013,AFRICA)
     */
    public static void richiesta6(StudentiPerContinenteEAnno st_3,StudentiPerContinenteEAnno st_4){
        int numCompare = 0;
        String stringaStato = null;
        for(int i = 1; i < st_4.getSps().length ; i++){
             for(int j = 1; j < st_3.getSps().length ; j++){
                 if(st_3.getSps()[j] != null && st_4.getSps()[i] != null){
                    if(st_3.getSps()[j].getStato().equals(st_4.getSps()[i].getStato())){
                         if(numCompare < (Integer.parseInt(st_4.getSps()[i].getTotaleStudenti()) - Integer.parseInt(st_3.getSps()[j].getTotaleStudenti()))){
                                numCompare = Integer.parseInt(st_4.getSps()[i].getTotaleStudenti()) - Integer.parseInt(st_3.getSps()[j].getTotaleStudenti());
                                stringaStato = st_3.getSps()[i].getStato();
                         }
                    }
                 }
             }
        }
        
        System.out.println("Stato africano con il maggiore incremento di studenti in Italia nel periodo dal 2000-2001 al 2012-2013:  " + stringaStato);
        
    }
    
    /**
     * metodo richiesta7() che permette all'utente di scegliere se serializzare l'array oppure caricarlo e visualizzarlo
     * @param st_1
     * @throws ClassNotFoundException 
     */
    public static void richiesta7(StudentiPerContinenteEAnno st_1) throws ClassNotFoundException{
        System.out.println("\nDesideri serializzare o carica l'oggetto?  ");
        System.out.println("  1  - Serializza");
        System.out.println("  2  - Carica");
        String scelta = input();
        
        switch(scelta){
            case "1":{
                try{
                st_1.serializzaOggetto();
                }catch(IOException e){
                    System.out.println("Errore durante la serializzazione dell'oggetto.");
                }
                break;
            }
            case "2":{
                try{
                st_1.caricaOggetto();
                }catch(IOException e){
                    System.out.println("Errore durante il caricamento dell'oggetto.");
                }
                break;
        }
            case "3":{
                System.out.println("Carica e visualizza dati da file.");
                try{
                st_1.caricaOggetto();
                }catch(IOException e){
                System.out.println("Errore durante il caricamento dell'oggetto.");
                richiesta4(st_1);
            }
            }
    }
    }/**
     * Semplice metodo che permette all'utente di inserire dati da tastiera
     * @return string
     */
    public static String input(){
        Scanner r = new Scanner(System.in);
        return r.nextLine();
    }
    
    /**
     * Metodo showRichiesta5() collegato al metodo richiesta5() che visualizza i risultati dell'operazione svolta nel metodo richiesta5()
     * @param femmine
     * @param maschi
     * @param tot 
     */
    public static void showRichiesta5(int femmine,int maschi,int tot){
        System.out.println("Dal 2000-2001 al 2012-2013 le studentesse americane femmine in Italia sono aumentate di:  " + femmine + " unità.");
        System.out.println("Dal 2000-2001 al 2012-2013 gli studenti americani maschi in Italia sono aumentati di:  " + maschi + " unità.");
        System.out.println("Dal 2000-2001 al 2012-2013 le studenti americani in Italia sono aumentati di:  " + tot + " unità.");
    }
    
    /**
     * Metodo chiediSeRiavviare() permette all'utente di scegliere se terminare o continuare l'esecuzione del programma
     */
    public static void chiediSeRiavviare(){
        System.out.println("Vuoi riavviare il programma?    s/n");
        String choice = input().toUpperCase();
        if(choice.equals("S")){
            continua = true;
        } else if(choice.equals("N")){
            continua = false;
            System.exit(0);
        }
    }

}

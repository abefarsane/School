/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package verificafarsane;
import java.util.Scanner;
import java.io.Serializable;
import java.io.*;
/**
 *
 * @author abdollah.farsane
 */
public class StudentiPerContinenteEAnno implements Serializable {
    private StudentiPerStatoEAnno[] stStatoAnno = new StudentiPerStatoEAnno[2527];
    private Scanner scanFile;
    static int i = 0;
    
    /**
     * Metodo costruttore che riceve anno(String) e continente(String) che va a leggere dal file regpie-StudentiStra_2090-all.csv i dati relativi ai parametri passati per istanziare
     * l'oggetto StudentiPerContinenteEAnno e memorizza tutta la stringa letta dal file csv in un oggetto di tipo StudentiPerStatoEAnno all'interno di un array sempre di tipo StudentiPerStatoEAnno
     * @param anno
     * @param continente 
     */
    public StudentiPerContinenteEAnno(String anno,String continente){
        
        try{
        scanFile = new Scanner(new File("/Users/" + System.getProperty("user.name") + "/Desktop/regpie-StudentiStra_2090-all.csv"));
        }catch(FileNotFoundException e){
            System.out.println("File non trovato nel percorso da lei definito.");
        }
        
        String consumaStringa = scanFile.nextLine();
        
        while(scanFile.hasNextLine()){
            String[] splitStringa = scanFile.nextLine().replace("\"", "").split(";");
            if(splitStringa[0].equals(anno) && splitStringa[1].equals(continente)){
                stStatoAnno[i] = new StudentiPerStatoEAnno(splitStringa[0],splitStringa[1],splitStringa[2],splitStringa[3],splitStringa[4],splitStringa[5]);
                i++;
            }
        }
    }
    /**
     * Getter dell'array di tipo StudentiPerStatoEAnno
     * @return StudentiPerStatoEAnno[]
     */
    public StudentiPerStatoEAnno[] getSps(){
        return stStatoAnno;
    }
    /**
     * metodo void che si occupa di serializzare l'oggetto
     * @throws IOException 
     */
    public void serializzaOggetto() throws IOException{
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("/Users/" + System.getProperty("user.name") + "/Desktop/StudentiContinenteSerializzati.bin"));
        out.writeObject(this.stStatoAnno);
        out.close();
        System.out.println("Serializzazione avvenuta con successo.");
    }
    /**
     * metodo void che si occupa del caricamento dell'oggetto da file precendentemente serializzato
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    public void caricaOggetto() throws IOException, ClassNotFoundException {
        ObjectInputStream in = new ObjectInputStream(new FileInputStream("/Users/" + System.getProperty("user.name") + "/Desktop/StudentiContinenteSerializzati.bin"));
        this.stStatoAnno = (StudentiPerStatoEAnno[]) in.readObject();
        
        in.close();
        System.out.println("Dati caricati con successo!");
    }

}

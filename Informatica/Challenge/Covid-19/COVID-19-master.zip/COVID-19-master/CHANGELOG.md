# Changelog

Tutte le modifiche al progetto, nuove funzionalità e informazioni sono documentate in questo file

## 2020-03-08

- Modificato dataset "dati-andamento-nazionale" riportando i totali dei dati delle Regioni
- Rimossa directory "shape-aree-contenimento" e creata "aree" con "shp" e "geojson"

## 2020-03-10

- Aggiornate le Aree secondo il nuovo DPCM 9 Marzo 2020

## 2020-03-11

- Trento e Bolzano rinominati in "dati-regioni e "dati-province" ("denominazione_regione") in "P.A. Bolzano" e "P.A. Trento"
- Friuli V. G. rinominata in "dati-regioni e "dati-province" ("denominazione_regione") in "Friuli Venezia Giulia"

## 2020-03-12

- Aggiunto Codice di Condotta in italiano (CODE_OF_CONDUCT.md) e in inglese (CODE_OF_CONDUCT_EN.md)
- Aggiunto Changelog in italiano (CHANGELOG.md) e in inglese (CHANGELOG_EN.md)
- Aggiornate le Aree secondo il nuovo DPCM 11 Marzo 2020

## Prossimi aggiornamenti

- Aggiunta "Note" in "dati-regioni", "dati-province" e "dati-andamento-nazionale"

package ES_Biblioteca;
import java.io.IOException;
import java.time.LocalDate;

 
public class esBiblioteca{
    public static void main(String[] args) throws Biblioteca.LibroException, InterruptedException, IOException{
        UserInterface ui = new UserInterface();
        ui.mainMenu();
    }

}